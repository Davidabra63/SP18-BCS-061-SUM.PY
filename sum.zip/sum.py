def add(x,y):
    result = x+y
    return result

n1 = int(input("enter the first number:"))
n2 = int(input("enter the second number:"))

res = add(n1,n2)
print(n1,"+",n2,"=",res)
         
